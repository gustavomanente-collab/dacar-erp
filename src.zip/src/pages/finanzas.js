import { supabase } from '../supabase.js'
import { generarReciboCobro, generarReciboComision } from '../recibos.js'
export async function renderFinanzas(contenedor, perfil) {
  // Roles definidos por Gustavo
  const esGerencia = perfil?.role === 'gerencia'
  const esAdmin    = perfil?.role === 'administrativo'
  const esVendedor = perfil?.role === 'vendedor'

contenedor.innerHTML = `
    <div class="p-4 max-w-5xl mx-auto">
      <div class="flex gap-2 mb-6 border-b border-gray-200 flex-wrap">
        <button onclick="tabFin('pendientes')" id="tab-pendientes"
          class="px-4 py-2 text-sm font-medium border-b-2 border-green-700 text-green-700">
          ⏳ ${esVendedor ? 'Estado de ventas' : 'Pendientes de cobro'}
        </button>
        <button onclick="tabFin('cobros')" id="tab-cobros"
          class="px-4 py-2 text-sm font-medium border-b-2 border-transparent text-gray-500 hover:text-gray-700">
          💰 Cobros registrados
        </button>
        ${!esVendedor ? `
        <button onclick="tabFin('proveedor')" id="tab-proveedor"
          class="px-4 py-2 text-sm font-medium border-b-2 border-transparent text-gray-500 hover:text-gray-700">
          🏭 Pagos proveedor
        </button>` : ''}
        ${esGerencia ? `
        <button onclick="tabFin('comisiones')" id="tab-comisiones"
          class="px-4 py-2 text-sm font-medium border-b-2 border-transparent text-gray-500 hover:text-gray-700">
          🤝 Comisiones
        </button>
        <button onclick="tabFin('calce')" id="tab-calce"
          class="px-4 py-2 text-sm font-medium border-b-2 border-transparent text-gray-500 hover:text-gray-700">
          ⚖️ Calce
        </button>` : ''}
        ${esGerencia || esAdmin ? `
        <button onclick="window.abrirSimuladorFlujo()"
          class="px-4 py-2 text-sm font-medium border-b-2 border-transparent text-gray-500 hover:text-gray-700 ml-auto">
          📊 Simulador caja
        </button>` : ''}
      </div>
      <div id="fin-content"></div>
    </div>
  `
  window.tabFin = (tab) => {
    ;['pendientes','cobros','proveedor','comisiones'].forEach(t => {
      const btn = document.getElementById(`tab-${t}`)
      // ESCUDO: Solo cambia el color si el botón existe en la pantalla para este rol
      if (btn) {
        btn.className = t === tab
          ? 'px-4 py-2 text-sm font-medium border-b-2 border-green-700 text-green-700'
          : 'px-4 py-2 text-sm font-medium border-b-2 border-transparent text-gray-500 hover:text-gray-700'
      }
    })
    if (tab === 'pendientes')  renderPendientes()
    if (tab === 'cobros')      renderCobros()
    if (tab === 'proveedor')   renderProveedor()
    if (tab === 'comisiones')  renderComisiones()
    if (tab === 'calce')       renderCalce()
  }

  async function renderPendientes() {
    const el = document.getElementById('fin-content')
    el.innerHTML = '<p class="text-gray-400 text-sm p-4">Cargando...</p>'

    const { data: cots } = await supabase
      .from('cotizaciones')
      .select(`*, clientes(id, nombre, obra, telefono, codigo)`)
      .eq('estado', 'aprobada')
      .order('numero', { ascending: false })

    if (!cots?.length) {
      el.innerHTML = '<p class="text-gray-400 text-sm p-4">No hay ventas aprobadas.</p>'
      return
    }

    const { data: cobros } = await supabase
      .from('cobros').select('cotizacion_id, monto_usd')

    const cobradoPorCot = {}
    ;(cobros || []).forEach(c => {
      cobradoPorCot[c.cotizacion_id] = (cobradoPorCot[c.cotizacion_id] || 0) + (c.monto_usd || 0)
    })

    el.innerHTML = `
      <div class="mb-4">
        <input id="busca-venta" type="text" placeholder="🔍 Buscar por cliente, código o N° ppto..."
          class="w-full rounded-lg border-gray-300 text-sm" />
      </div>
      <div id="tablero-ventas" class="space-y-2">
        ${cots.map(cot => {
          const nro = `2026-${String(cot.numero).padStart(3,'0')}`
          const cobrado = cobradoPorCot[cot.id] || 0
          const bruto = cot.total_bruto_usd || cot.total_final || 0
          const saldo = bruto - cobrado
          const pct = bruto > 0 ? Math.min(100, cobrado / bruto * 100) : 0
          const color = saldo <= 0 ? 'bg-green-500' : cobrado > 0 ? 'bg-yellow-400' : 'bg-gray-300'
          const estado = saldo <= 0 ? '✅ Cobrado' : cobrado > 0 ? '⏳ Parcial' : '🔴 Pendiente'
          return `
            <div class="venta-card bg-white border border-gray-200 rounded-xl px-4 py-3 shadow-sm cursor-pointer hover:border-green-300 transition-colors"
              onclick="abrirFichaVenta('${cot.id}')"
              data-search="${(cot.clientes?.nombre||'').toLowerCase()} ${(cot.clientes?.codigo||'').toLowerCase()} ${nro.toLowerCase()}">
              <div class="flex items-center justify-between">
                <div class="flex items-center gap-3">
                  <div>
                    <p class="font-bold text-gray-900 text-sm">${nro}</p>
                    <p class="text-xs text-gray-400">${cot.clientes?.codigo || ''}</p>
                  </div>
                  <div>
                    <p class="font-medium text-gray-800">${cot.clientes?.nombre || ''}</p>
                    <p class="text-xs text-gray-500">${cot.clientes?.obra || ''}</p>
                  </div>
                </div>
                <!-- Liquidar comisión completa -->
          <div class="border-t pt-3 mb-3">
            <div class="bg-purple-50 border border-purple-200 rounded-lg p-3 flex items-center justify-between">
              <div>
                <p class="text-xs font-semibold text-purple-700">Comisión total de esta venta</p>
                <p class="text-sm font-black text-purple-800">U$S ${((cot.total_final - cot.total_neto) * 0.25).toFixed(2)}</p>
                <p class="text-xs text-purple-500">25% sobre utilidad neta de U$S ${(cot.total_final - cot.total_neto).toFixed(2)}</p>
              </div>
              <button onclick="liquidarVentaCompleta('${cot.id}', ${cot.total_final}, ${cot.total_neto})"
                class="bg-purple-700 hover:bg-purple-900 text-white text-xs font-medium px-3 py-2 rounded-lg">
                💸 Liquidar 100%
              </button>
            </div>
          </div>
                <div class="text-right">
                  <p class="text-xs text-gray-400">${estado}</p>
                  <p class="font-bold text-green-700 text-sm">U$S ${bruto.toFixed(2)}</p>
                  <p class="text-xs ${saldo > 0 ? 'text-red-500' : 'text-green-600'}">
                    ${saldo > 0 ? `Saldo: U$S ${saldo.toFixed(2)}` : 'Cancelado'}
                  </p>
                </div>
              </div>
              <div class="mt-2 bg-gray-100 rounded-full h-1.5">
                <div class="${color} h-1.5 rounded-full" style="width:${pct}%"></div>
              </div>
            </div>
          `
        }).join('')}
      </div>
    `

    document.getElementById('busca-venta').addEventListener('input', e => {
      const txt = e.target.value.toLowerCase()
      document.querySelectorAll('.venta-card').forEach(card => {
        card.style.display = card.dataset.search.includes(txt) ? '' : 'none'
      })
    })

    window.abrirFichaVenta = async (cotId) => {
      const cot = cots.find(c => c.id === cotId)
      if (!cot) return

      const { data: cobrosVenta } = await supabase
        .from('cobros').select('*').eq('cotizacion_id', cotId).order('fecha')

      const nro = `2026-${String(cot.numero).padStart(3,'0')}`
      const bruto = cot.total_bruto_usd || cot.total_final || 0
      const totalCobrado = (cobrosVenta || []).reduce((s, c) => s + (c.monto_usd || 0), 0)
      const saldo = bruto - totalCobrado

      const modal = document.createElement('div')
      modal.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,0.5);z-index:9999;display:flex;align-items:center;justify-content:center;overflow-y:auto;padding:20px;'
      modal.innerHTML = `
        <div style="background:white;border-radius:16px;padding:24px;width:100%;max-width:650px;max-height:90vh;overflow-y:auto;">
          <div class="flex items-start justify-between mb-4">
            <div>
              <p class="text-xs text-gray-400">Venta confirmada</p>
              <h3 class="text-xl font-black text-gray-900">${nro}</h3>
              <p class="text-sm font-semibold text-gray-700">${cot.clientes?.nombre || ''} <span class="text-gray-400 text-xs">${cot.clientes?.codigo || ''}</span></p>
              <p class="text-xs text-gray-500">${cot.clientes?.obra || ''} ${cot.clientes?.telefono ? '· Tel: ' + cot.clientes.telefono : ''}</p>
            </div>
            <button onclick="this.closest('[style]').remove()" class="text-gray-400 hover:text-gray-600 text-2xl font-bold">×</button>
          </div>

          <div class="grid grid-cols-3 gap-3 mb-4">
            <div class="bg-green-50 border border-green-200 rounded-lg p-3 text-center">
              <p class="text-xs text-green-600">Total a cobrar</p>
              <p class="font-black text-green-700">U$S ${bruto.toFixed(2)}</p>
              ${cot.facturado ? `<p class="text-xs text-gray-400">IVA ${cot.iva_pct}% incl.</p>` : '<p class="text-xs text-gray-400">Sin factura</p>'}
            </div>
            <div class="bg-blue-50 border border-blue-200 rounded-lg p-3 text-center">
              <p class="text-xs text-blue-600">Cobrado</p>
              <p class="font-black text-blue-700">U$S ${totalCobrado.toFixed(2)}</p>
            </div>
            <div class="bg-${saldo > 0 ? 'red' : 'gray'}-50 border border-${saldo > 0 ? 'red' : 'gray'}-200 rounded-lg p-3 text-center">
              <p class="text-xs text-${saldo > 0 ? 'red' : 'gray'}-600">Saldo</p>
              <p class="font-black text-${saldo > 0 ? 'red' : 'gray'}-700">U$S ${saldo.toFixed(2)}</p>
            </div>
          </div>

          <div class="bg-gray-100 rounded-full h-3 mb-4">
            <div class="${saldo <= 0 ? 'bg-green-500' : 'bg-yellow-400'} h-3 rounded-full"
              style="width:${Math.min(100, bruto > 0 ? totalCobrado/bruto*100 : 0)}%"></div>
          </div>

          <div class="mb-4">
            <h4 class="font-semibold text-gray-700 text-sm mb-2">Cobros registrados</h4>
            ${cobrosVenta?.length ? `
              <table class="w-full text-xs">
                <thead><tr class="bg-gray-100">
                  <th class="px-2 py-1 text-left">Fecha</th>
                  <th class="px-2 py-1 text-left">Concepto</th>
                  <th class="px-2 py-1 text-left">Forma</th>
                  <th class="px-2 py-1 text-right">U$S</th>
                  <th class="px-2 py-1 text-right">$</th>
                  <th class="px-2 py-1"></th>
                </tr></thead>
                <tbody>
                  ${cobrosVenta.map((c, i) => `
                    <tr class="${i % 2 === 0 ? 'bg-white' : 'bg-gray-50'}">
                      <td class="px-2 py-1">${new Date(c.fecha + 'T12:00:00').toLocaleDateString('es-AR')}</td>
                      <td class="px-2 py-1">${c.concepto || ''}</td>
                      <td class="px-2 py-1">${c.tipo_pago}</td>
                      <td class="px-2 py-1 text-right font-bold text-green-700">U$S ${(c.monto_usd||0).toFixed(2)}</td>
                      <td class="px-2 py-1 text-right text-blue-600">$ ${Math.round(c.monto_ars||0).toLocaleString('es-AR')}</td>
                      <td class="px-2 py-1 text-center">
                        ${esGerencia || esAdmin ? `<button onclick="borrarCobroFicha('${c.id}', '${cotId}')" class="text-red-400 hover:text-red-600 font-bold">✕</button>` : ''}
                      </td>
                    </tr>
                  `).join('')}
                </tbody>
              </table>
            ` : '<p class="text-gray-400 text-xs">Sin cobros aún.</p>'}
          </div>

          ${esGerencia || esAdmin ? `
          <div class="bg-gray-50 rounded-lg p-3 mb-4">
            <p class="text-xs font-semibold text-gray-600 mb-2">Configuración de cobro</p>
            <div class="grid grid-cols-3 gap-2">
              <div>
                <label class="block text-xs text-gray-500 mb-1">Facturación</label>
                <select id="ficha-fact" class="w-full rounded border-gray-300 text-xs">
                  <option value="0" ${!cot.facturado ? 'selected' : ''}>Sin factura</option>
                  <option value="10.5" ${cot.facturado && cot.iva_pct == 10.5 ? 'selected' : ''}>IVA 10.5%</option>
                  <option value="21" ${cot.facturado && cot.iva_pct == 21 ? 'selected' : ''}>IVA 21%</option>
                </select>
              </div>
              <div>
                <label class="block text-xs text-gray-500 mb-1">T/C</label>
                <input id="ficha-tc" type="number" value="${cot.tc_cobro || 1150}" class="w-full rounded border-gray-300 text-xs" />
              </div>
              <div class="flex items-end">
                <button onclick="guardarConfigFicha('${cot.id}', ${cot.total_final})"
                  class="w-full bg-gray-700 text-white text-xs py-1.5 rounded">Guardar</button>
              </div>
            </div>
          </div>
          ` : ''}

          ${saldo > 0 && (esGerencia || esAdmin) ? `
          <div class="border-t pt-4">
            <h4 class="font-semibold text-gray-700 text-sm mb-2">Registrar cobro</h4>
            <div class="grid grid-cols-2 gap-2 mb-2">
              <div>
                <label class="block text-xs text-gray-500 mb-1">Fecha</label>
                <input id="ficha-fecha" type="date" value="${new Date().toISOString().split('T')[0]}"
                  class="w-full rounded border-gray-300 text-xs" />
              </div>
              <div>
                <label class="block text-xs text-gray-500 mb-1">Monto U$S</label>
                <input id="ficha-monto" type="number" min="0" step="0.01" placeholder="${saldo.toFixed(2)}"
                  class="w-full rounded border-gray-300 text-xs" />
              </div>
              <div>
                <label class="block text-xs text-gray-500 mb-1">Forma de pago</label>
                <select id="ficha-forma" class="w-full rounded border-gray-300 text-xs">
                  <option value="transferencia">Transferencia</option>
                  <option value="efectivo">Efectivo</option>
                  <option value="cheque">Cheque</option>
                  <option value="otro">Otro</option>
                </select>
              </div>
              <div>
              <div>
                <label class="block text-xs text-gray-500 mb-1">Fecha acreditación</label>
                <input id="ficha-facred" type="date" value="${new Date().toISOString().split('T')[0]}"
                  class="w-full rounded border-gray-300 text-xs" />
              </div>
              <div>
                <label class="block text-xs text-gray-500 mb-1">N° Cheque (opcional)</label>
                <input id="ficha-cheque" type="text" placeholder="Ej: 12345678"
                  class="w-full rounded border-gray-300 text-xs" />
              </div>
                <label class="block text-xs text-gray-500 mb-1">Concepto</label>
                <input id="ficha-concepto" type="text" placeholder="Anticipo, saldo..."
                  class="w-full rounded border-gray-300 text-xs" />
              </div>
            </div>
            <button onclick="cobrarFicha('${cot.id}', '${cot.cliente_id}')"
              class="w-full bg-green-700 hover:bg-green-900 text-white text-sm font-medium py-2 rounded-lg">
              💰 Registrar cobro
            </button>
            <p id="ficha-msg" class="hidden text-xs text-green-700 mt-1 text-center"></p>
          </div>
          ` : saldo <= 0 ? '<div class="bg-green-50 rounded-lg p-3 text-center text-sm font-semibold text-green-700">✅ Venta completamente cobrada</div>' : ''}
        </div>
      `
      document.body.appendChild(modal)
      modal.addEventListener('click', e => { if (e.target === modal) modal.remove() })

      window.guardarConfigFicha = async (id, totalNeto) => {
        const ivaPct = parseFloat(document.getElementById('ficha-fact').value) || 0
        const tc = parseFloat(document.getElementById('ficha-tc').value) || 1150
        const bruto = totalNeto * (1 + ivaPct / 100)
        await supabase.from('cotizaciones').update({
          facturado: ivaPct > 0, iva_pct: ivaPct, total_bruto_usd: bruto, tc_cobro: tc
        }).eq('id', id)
        modal.remove()
        renderPendientes()
      }

      window.cobrarFicha = async (cotId, clienteId) => {
        const monto = parseFloat(document.getElementById('ficha-monto').value) || 0
        const tc = parseFloat(document.getElementById('ficha-tc')?.value) || cot.tc_cobro || 1150
        if (!monto) { alert('Ingresá el monto'); return }
const { error } = await supabase.from('cobros').insert({
          cotizacion_id: cotId,
          cliente_id: clienteId,
          fecha: document.getElementById('ficha-fecha').value,
          fecha_acreditacion: document.getElementById('ficha-facred')?.value || document.getElementById('ficha-fecha').value,
          nro_cheque: document.getElementById('ficha-cheque')?.value || null,
          monto_usd: monto,
          monto_ars: monto * tc,
          tc,
          tipo_pago: document.getElementById('ficha-forma').value,
          concepto: document.getElementById('ficha-concepto').value || 'Cobro',
        })
                if (error) { alert('Error: ' + error.message); return }
        modal.remove()
        renderPendientes()
      }
window.liquidarVentaCompleta = async (cotId, totalFinal, totalNeto) => {
        const utilidad = totalFinal - totalNeto
        const comision = utilidad * 0.25
        const tc = parseFloat(prompt('Tipo de cambio $ / U$S:', '1150')) || 1150

        if (!confirm(`¿Liquidar comisión completa de U$S ${comision.toFixed(2)} ($ ${Math.round(comision * tc).toLocaleString('es-AR')}) sobre utilidad de U$S ${utilidad.toFixed(2)}?`)) return

        const { data: liq, error } = await supabase
          .from('liquidaciones')
          .insert({
            fecha: new Date().toISOString().split('T')[0],
            monto_usd: comision,
            monto_ars: comision * tc,
            tc,
            notas: `Liquidación 100% venta 2026-${String(cot.numero).padStart(3,'0')}`
          })
          .select().single()

        if (error) { alert('Error: ' + error.message); return }

        alert(`✅ Comisión de U$S ${comision.toFixed(2)} liquidada correctamente`)
        modal.remove()
        renderPendientes()
      }
window.borrarCobroFicha = async (id, cotId) => {
        const clave = prompt('Clave de gerencia:')
        if (clave !== 'dacar2024') { alert('Clave incorrecta'); return }
        if (!confirm('¿Confirmás? Se borrarán también los registros relacionados.')) return
        await supabase.from('liquidacion_cobros').delete().eq('cobro_id', id)
        await supabase.from('recibos').delete().eq('cobro_id', id)
        await supabase.from('cobros').delete().eq('id', id)
                modal.remove()
        abrirFichaVenta(cotId)
      }
    }
  }

  async function renderCobros() {
    const el = document.getElementById('fin-content')
    el.innerHTML = '<p class="text-gray-400 text-sm p-4">Cargando...</p>'

    const { data } = await supabase
      .from('cobros')
      .select(`*, clientes(nombre), cotizaciones(numero)`)
      .order('fecha', { ascending: false })

    if (!data?.length) {
      el.innerHTML = '<p class="text-gray-400 text-sm p-4">No hay cobros registrados.</p>'
      return
    }

    const totalUsd = data.reduce((s, c) => s + (c.monto_usd || 0), 0)
    const totalArs = data.reduce((s, c) => s + (c.monto_ars || 0), 0)

    el.innerHTML = `
      <div class="grid grid-cols-2 gap-3 mb-4">
        <div class="bg-green-50 border border-green-200 rounded-xl p-3 text-center">
          <p class="text-xs text-green-600 font-medium">Total cobrado U$S</p>
          <p class="text-xl font-black text-green-700">U$S ${totalUsd.toFixed(2)}</p>
        </div>
        <div class="bg-blue-50 border border-blue-200 rounded-xl p-3 text-center">
          <p class="text-xs text-blue-600 font-medium">Total cobrado $</p>
          <p class="text-xl font-black text-blue-700">$ ${Math.round(totalArs).toLocaleString('es-AR')}</p>
        </div>
      </div>
      <div class="bg-white border border-gray-200 rounded-xl shadow-sm overflow-hidden">
        <table class="w-full text-xs">
          <thead><tr class="bg-gray-900 text-white">
            <th class="px-3 py-2 text-left">Fecha</th>
            <th class="px-3 py-2 text-left">Cliente</th>
            <th class="px-3 py-2 text-left">Ppto</th>
            <th class="px-3 py-2 text-left">Concepto</th>
            <th class="px-3 py-2 text-left">Forma</th>
            <th class="px-3 py-2 text-right">U$S</th>
            <th class="px-3 py-2 text-right">$</th>
            <th class="px-3 py-2 text-center">T/C</th>
            <th class="px-3 py-2"></th>
          </tr></thead>
          <tbody>
            ${data.map((c, i) => `
              <tr class="${i % 2 === 0 ? 'bg-white' : 'bg-gray-50'}">
                <td class="px-3 py-2">${new Date(c.fecha + 'T12:00:00').toLocaleDateString('es-AR')}</td>
                <td class="px-3 py-2 font-medium">${c.clientes?.nombre || ''}</td>
                <td class="px-3 py-2">${c.cotizaciones?.numero ? '2026-' + String(c.cotizaciones.numero).padStart(3,'0') : '-'}</td>
                <td class="px-3 py-2">${c.concepto || ''}</td>
                <td class="px-3 py-2">${c.tipo_pago}</td>
                <td class="px-3 py-2 text-right font-bold text-green-700">U$S ${(c.monto_usd||0).toFixed(2)}</td>
                <td class="px-3 py-2 text-right text-blue-700">$ ${Math.round(c.monto_ars||0).toLocaleString('es-AR')}</td>
                <td class="px-3 py-2 text-center text-gray-500">${c.tc || '-'}</td>
                <td class="px-3 py-2 text-center">
<button onclick="imprimirReciboCobro('${c.id}')" class="text-blue-500 hover:text-blue-700 text-xs mr-1">🖨️</button>
                <button onclick="borrarCobro('${c.id}')" class="text-red-400 hover:text-red-600 font-bold">✕</button>                </td>
              </tr>
            `).join('')}
          </tbody>
        </table>
      </div>
    `
window.imprimirReciboCobro = async (id) => {
      const cobro = data.find(c => c.id === id)
      if (!cobro) return

      // Calcular saldo pendiente
      const { data: todosLosCobros } = await supabase
        .from('cobros')
        .select('monto_usd')
        .eq('cotizacion_id', cobro.cotizacion_id)

      const totalCobrado = (todosLosCobros || []).reduce((s, c) => s + (c.monto_usd || 0), 0)

      const { data: cot } = await supabase
        .from('cotizaciones')
        .select('numero, total_bruto_usd, total_final')
        .eq('id', cobro.cotizacion_id)
        .single()

      const totalVenta = cot?.total_bruto_usd || cot?.total_final || 0
      const saldo = totalVenta - totalCobrado

      await generarReciboCobro({
        ...cobro,
        cliente_nombre: cobro.clientes?.nombre,
        nro_ppto: cot?.numero,
        saldo_usd: saldo
      })
    }

window.borrarCobro = async (id) => {
      const clave = prompt('Clave de gerencia:')
      if (clave !== 'dacar2024') { alert('Clave incorrecta'); return }
      if (!confirm('¿Confirmás? Se borrarán también los registros relacionados.')) return

      // Borrar registros relacionados primero
      await supabase.from('liquidacion_cobros').delete().eq('cobro_id', id)
      await supabase.from('recibos').delete().eq('cobro_id', id)
      await supabase.from('cobros').delete().eq('id', id)
      renderCobros()
    }  }

  async function renderProveedor() {
    const el = document.getElementById('fin-content')
    el.innerHTML = `
      <div class="bg-white border border-gray-200 rounded-xl p-5 shadow-sm mb-4">
        <h3 class="font-semibold text-gray-700 mb-4">Registrar pago a proveedor</h3>
        <div class="grid grid-cols-2 gap-3">
          <div>
            <label class="block text-xs text-gray-500 mb-1">Fecha</label>
            <input id="prov-fecha" type="date" value="${new Date().toISOString().split('T')[0]}"
              class="w-full rounded-lg border-gray-300 text-sm" />
          </div>
          <div>
            <label class="block text-xs text-gray-500 mb-1">Monto U$S</label>
            <input id="prov-monto" type="number" min="0" step="0.01" placeholder="0.00"
              class="w-full rounded-lg border-gray-300 text-sm" />
          </div>
          <div>
            <label class="block text-xs text-gray-500 mb-1">T/C $ x U$S</label>
            <input id="prov-tc" type="number" value="1150"
              class="w-full rounded-lg border-gray-300 text-sm" />
          </div>
          <div>
            <label class="block text-xs text-gray-500 mb-1">Forma de pago</label>
            <select id="prov-tipo" class="w-full rounded-lg border-gray-300 text-sm">
              <option value="transferencia">Transferencia</option>
              <option value="efectivo">Efectivo</option>
              <option value="cheque">Cheque</option>
              <option value="otro">Otro</option>
            </select>
          </div>
          <div>
          <div class="col-span-2">
            <label class="block text-xs text-gray-500 mb-1">Vincular a cotización (opcional)</label>
            <select id="prov-cot" class="w-full rounded-lg border-gray-300 text-sm">
              <option value="">Sin cotización específica</option>
            </select>
          </div>
            <label class="block text-xs text-gray-500 mb-1">N° Factura</label>
            <input id="prov-factura" type="text" placeholder="0001-00001234"
              class="w-full rounded-lg border-gray-300 text-sm" />
              <div>
            <label class="block text-xs text-gray-500 mb-1">Fecha acreditación</label>
            <input id="prov-facred" type="date" value="${new Date().toISOString().split('T')[0]}"
              class="w-full rounded-lg border-gray-300 text-sm" />
          </div>
          <div>
            <label class="block text-xs text-gray-500 mb-1">N° Cheque (opcional)</label>
            <input id="prov-cheque" type="text" placeholder="Ej: 12345678"
              class="w-full rounded-lg border-gray-300 text-sm" />
          </div>
          </div>
          <div>
            <label class="block text-xs text-gray-500 mb-1">Concepto</label>
            <input id="prov-concepto" type="text" placeholder="Ej: Compra paneles COVER LT"
              class="w-full rounded-lg border-gray-300 text-sm" />
          </div>
        </div>
        <button id="btn-guardar-prov"
          class="mt-4 bg-gray-800 hover:bg-gray-900 text-white text-sm font-medium px-5 py-2 rounded-lg">
          💾 Registrar pago
        </button>
        <p id="msg-prov" class="hidden text-sm mt-2 text-green-700"></p>
      </div>
      <div class="bg-white border border-gray-200 rounded-xl shadow-sm overflow-hidden">
        <div id="lista-prov"><p class="text-gray-400 text-sm p-4">Cargando...</p></div>
      </div>
    `
// Cargar cotizaciones aprobadas para vincular
    const { data: cotsAprobadas } = await supabase
      .from('cotizaciones')
      .select('id, numero, clientes(nombre)')
      .eq('estado', 'aprobada')
      .order('numero', { ascending: false })

    const selProvCot = document.getElementById('prov-cot')
    ;(cotsAprobadas || []).forEach(c => {
      const nro = `2026-${String(c.numero).padStart(3,'0')}`
      selProvCot.add(new Option(`${nro} — ${c.clientes?.nombre || ''}`, c.id))
    })
    document.getElementById('btn-guardar-prov').addEventListener('click', async () => {
      const monto = parseFloat(document.getElementById('prov-monto').value) || 0
      const tc = parseFloat(document.getElementById('prov-tc').value) || 1150
      if (!monto) { alert('Ingresá el monto'); return }
const cotId = document.getElementById('prov-cot').value
      const { error } = await supabase.from('pagos_proveedor').insert({
        fecha: document.getElementById('prov-fecha').value,
        fecha_acreditacion: document.getElementById('prov-facred')?.value || document.getElementById('prov-fecha').value,
        nro_cheque: document.getElementById('prov-cheque')?.value || null,
        monto_usd: monto,
        tipo_pago: document.getElementById('prov-tipo').value,
        nro_factura: document.getElementById('prov-factura').value,
        concepto: document.getElementById('prov-concepto').value,
        cotizacion_id: cotId || null
      })
                  if (error) { alert('Error: ' + error.message); return }
      const msgEl = document.getElementById('msg-prov')
      msgEl.textContent = `✅ Pago de U$S ${monto} ($ ${Math.round(monto*tc).toLocaleString('es-AR')}) registrado`
      msgEl.classList.remove('hidden')
      document.getElementById('prov-monto').value = ''
      document.getElementById('prov-factura').value = ''
      document.getElementById('prov-concepto').value = ''
      cargarProv()
    })

    cargarProv()
  }

  async function cargarProv() {
    const { data } = await supabase
      .from('pagos_proveedor').select('*').order('fecha', { ascending: false }).limit(50)
    const el = document.getElementById('lista-prov')
    if (!data?.length) { el.innerHTML = '<p class="text-gray-400 text-sm p-4">No hay pagos.</p>'; return }
    const total = data.reduce((s, p) => s + (p.monto_usd || 0), 0)
    el.innerHTML = `
      <div class="p-3 bg-gray-50 border-b flex justify-between">
        <span class="text-sm font-medium text-gray-700">Total pagado al proveedor:</span>
        <span class="text-sm font-bold">U$S ${total.toFixed(2)}</span>
      </div>
      <table class="w-full text-xs">
        <thead><tr class="bg-gray-900 text-white">
          <th class="px-3 py-2 text-left">Fecha</th>
          <th class="px-3 py-2 text-left">Concepto</th>
          <th class="px-3 py-2 text-left">N° Factura</th>
          <th class="px-3 py-2 text-left">Forma</th>
          <th class="px-3 py-2 text-right">U$S</th>
          <th class="px-3 py-2"></th>
        </tr></thead>
        <tbody>
          ${data.map((p, i) => `
            <tr class="${i % 2 === 0 ? 'bg-white' : 'bg-gray-50'}">
              <td class="px-3 py-2">${new Date(p.fecha + 'T12:00:00').toLocaleDateString('es-AR')}</td>
              <td class="px-3 py-2">${p.concepto || ''}</td>
              <td class="px-3 py-2">${p.nro_factura || '-'}</td>
              <td class="px-3 py-2">${p.tipo_pago}</td>
              <td class="px-3 py-2 text-right font-bold">U$S ${(p.monto_usd||0).toFixed(2)}</td>
              <td class="px-3 py-2 text-center">
                <button onclick="borrarProv('${p.id}')" class="text-red-400 hover:text-red-600 font-bold">✕</button>
              </td>
            </tr>
          `).join('')}
        </tbody>
      </table>
    `
    window.borrarProv = async (id) => {
      const clave = prompt('Clave de gerencia:')
      if (clave !== 'dacar2024') { alert('Clave incorrecta'); return }
      if (!confirm('¿Confirmás?')) return
      await supabase.from('pagos_proveedor').delete().eq('id', id)
      cargarProv()
    }
  }
async function renderCalce() {
    const el = document.getElementById('fin-content')
    el.innerHTML = '<p class="text-gray-400 text-sm p-4">Cargando...</p>'

    const { data: cots } = await supabase
      .from('cotizaciones')
      .select('*, clientes(nombre, obra)')
      .eq('estado', 'aprobada')
      .order('numero', { ascending: false })

    const { data: cobros } = await supabase
      .from('cobros').select('*').order('fecha_acreditacion')

    const { data: pagos } = await supabase
      .from('pagos_proveedor').select('*').order('fecha_acreditacion')

    if (!cots?.length) {
      el.innerHTML = '<p class="text-gray-400 text-sm p-4">No hay ventas aprobadas.</p>'
      return
    }

    const calce = cots.map(cot => {
      const cobradoVenta = (cobros || [])
        .filter(c => c.cotizacion_id === cot.id)
        .reduce((s, c) => s + (c.monto_usd || 0), 0)
      const pagadoVenta = (pagos || [])
        .filter(p => p.cotizacion_id === cot.id)
        .reduce((s, p) => s + (p.monto_usd || 0), 0)
      const totalVenta  = cot.total_bruto_usd || cot.total_final || 0
      const costoVenta  = cot.total_neto || 0
      const saldoCobrar = totalVenta - cobradoVenta
      const saldoPagar  = costoVenta - pagadoVenta
      const resultado   = cobradoVenta - pagadoVenta
      return { ...cot, cobradoVenta, pagadoVenta, totalVenta, costoVenta, saldoCobrar, saldoPagar, resultado }
    })

    const totalCobrado = calce.reduce((s, c) => s + c.cobradoVenta, 0)
    const totalPagado  = calce.reduce((s, c) => s + c.pagadoVenta, 0)
    const posicionCaja = totalCobrado - totalPagado

    el.innerHTML = `
      <div class="grid grid-cols-3 gap-3 mb-4">
        <div class="bg-green-50 border border-green-200 rounded-xl p-4 text-center">
          <p class="text-xs text-green-600 font-medium mb-1">Total cobrado clientes</p>
          <p class="text-xl font-black text-green-700">U$S ${totalCobrado.toFixed(2)}</p>
        </div>
        <div class="bg-red-50 border border-red-200 rounded-xl p-4 text-center">
          <p class="text-xs text-red-600 font-medium mb-1">Total pagado proveedor</p>
          <p class="text-xl font-black text-red-700">U$S ${totalPagado.toFixed(2)}</p>
        </div>
        <div class="bg-${posicionCaja >= 0 ? 'blue' : 'orange'}-50 border border-${posicionCaja >= 0 ? 'blue' : 'orange'}-200 rounded-xl p-4 text-center">
          <p class="text-xs text-${posicionCaja >= 0 ? 'blue' : 'orange'}-600 font-medium mb-1">Posición de caja</p>
          <p class="text-xl font-black text-${posicionCaja >= 0 ? 'blue' : 'orange'}-700">U$S ${posicionCaja.toFixed(2)}</p>
          <p class="text-xs text-gray-400">${posicionCaja >= 0 ? '✅ Positiva' : '⚠️ Negativa'}</p>
        </div>
      </div>

      <div class="bg-white border border-gray-200 rounded-xl shadow-sm overflow-hidden mb-4">
        <div class="bg-gray-50 px-4 py-3 border-b">
          <h4 class="font-semibold text-gray-700 text-sm">Calce por venta</h4>
        </div>
        <div class="overflow-x-auto">
          <table class="w-full text-xs">
            <thead><tr class="bg-gray-900 text-white">
              <th class="px-3 py-2 text-left">N° Ppto</th>
              <th class="px-3 py-2 text-left">Cliente</th>
              <th class="px-3 py-2 text-right">Venta U$S</th>
              <th class="px-3 py-2 text-right">Cobrado</th>
              <th class="px-3 py-2 text-right">Por cobrar</th>
              <th class="px-3 py-2 text-right">Costo lista</th>
              <th class="px-3 py-2 text-right">Pagado prov.</th>
              <th class="px-3 py-2 text-right">Por pagar</th>
              <th class="px-3 py-2 text-right">Resultado</th>
            </tr></thead>
            <tbody>
              ${calce.map((c, i) => `
                <tr class="${i % 2 === 0 ? 'bg-white' : 'bg-gray-50'}">
                  <td class="px-3 py-2 font-bold">2026-${String(c.numero).padStart(3,'0')}</td>
                  <td class="px-3 py-2">${c.clientes?.nombre || ''}</td>
                  <td class="px-3 py-2 text-right">U$S ${c.totalVenta.toFixed(2)}</td>
                  <td class="px-3 py-2 text-right text-green-700 font-medium">U$S ${c.cobradoVenta.toFixed(2)}</td>
                  <td class="px-3 py-2 text-right ${c.saldoCobrar > 0 ? 'text-orange-600' : 'text-gray-400'}">
                    ${c.saldoCobrar > 0 ? `U$S ${c.saldoCobrar.toFixed(2)}` : '✅'}
                  </td>
                  <td class="px-3 py-2 text-right text-gray-500">U$S ${c.costoVenta.toFixed(2)}</td>
                  <td class="px-3 py-2 text-right text-red-600 font-medium">U$S ${c.pagadoVenta.toFixed(2)}</td>
                  <td class="px-3 py-2 text-right ${c.saldoPagar > 0 ? 'text-red-500' : 'text-gray-400'}">
                    ${c.saldoPagar > 0 ? `U$S ${c.saldoPagar.toFixed(2)}` : '✅'}
                  </td>
                  <td class="px-3 py-2 text-right font-bold ${c.resultado >= 0 ? 'text-green-700' : 'text-red-600'}">
                    U$S ${c.resultado.toFixed(2)}
                  </td>
                </tr>
              `).join('')}
            </tbody>
            <tfoot>
              <tr class="bg-gray-900 text-white font-bold">
                <td colspan="3" class="px-3 py-2 text-xs">TOTALES</td>
                <td class="px-3 py-2 text-right text-xs text-green-300">U$S ${totalCobrado.toFixed(2)}</td>
                <td></td>
                <td></td>
                <td class="px-3 py-2 text-right text-xs text-red-300">U$S ${totalPagado.toFixed(2)}</td>
                <td></td>
                <td class="px-3 py-2 text-right text-xs ${posicionCaja >= 0 ? 'text-blue-300' : 'text-orange-300'}">
                  U$S ${posicionCaja.toFixed(2)}
                </td>
              </tr>
            </tfoot>
          </table>
        </div>
      </div>
    `

// Vencimientos próximos 30 días
    const hoy = new Date()
    const en30 = new Date(hoy.getTime() + 30 * 24 * 60 * 60 * 1000)
    const vencimientos = []

    ;(cobros || []).forEach(c => {
      const facred = c.fecha_acreditacion || c.fecha
      const d = new Date(facred + 'T12:00:00')
      if (d >= hoy && d <= en30) {
        vencimientos.push({ fecha: facred, tipo: 'cobro', descripcion: c.concepto || 'Cobro', monto: c.monto_usd, cheque: c.nro_cheque })
      }
    })
    ;(pagos || []).forEach(p => {
      const facred = p.fecha_acreditacion || p.fecha
      const d = new Date(facred + 'T12:00:00')
      if (d >= hoy && d <= en30) {
        vencimientos.push({ fecha: facred, tipo: 'pago', descripcion: p.concepto || 'Pago proveedor', monto: p.monto_usd, cheque: p.nro_cheque })
      }
    })
    vencimientos.sort((a, b) => new Date(a.fecha) - new Date(b.fecha))

    if (vencimientos.length) {
      el.innerHTML += `
        <div class="bg-white border border-gray-200 rounded-xl shadow-sm overflow-hidden mt-4">
          <div class="bg-blue-50 px-4 py-3 border-b border-blue-100">
            <h4 class="font-semibold text-blue-700 text-sm">📅 Vencimientos próximos 30 días</h4>
          </div>
          <table class="w-full text-xs">
            <thead><tr class="bg-gray-900 text-white">
              <th class="px-3 py-2 text-left">Fecha acred.</th>
              <th class="px-3 py-2 text-left">Tipo</th>
              <th class="px-3 py-2 text-left">Descripción</th>
              <th class="px-3 py-2 text-left">N° Cheque</th>
              <th class="px-3 py-2 text-right">Monto U$S</th>
            </tr></thead>
            <tbody>
              ${vencimientos.map((v, i) => `
                <tr class="${i % 2 === 0 ? 'bg-white' : 'bg-gray-50'}">
                  <td class="px-3 py-2 font-medium">${new Date(v.fecha + 'T12:00:00').toLocaleDateString('es-AR')}</td>
                  <td class="px-3 py-2">
                    <span class="px-2 py-0.5 rounded-full text-xs font-medium ${v.tipo === 'cobro' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}">
                      ${v.tipo === 'cobro' ? '⬆️ Ingreso' : '⬇️ Egreso'}
                    </span>
                  </td>
                  <td class="px-3 py-2">${v.descripcion}</td>
                  <td class="px-3 py-2 text-gray-400">${v.cheque || '-'}</td>
                  <td class="px-3 py-2 text-right font-bold ${v.tipo === 'cobro' ? 'text-green-700' : 'text-red-600'}">
                    ${v.tipo === 'cobro' ? '+' : '-'} U$S ${(v.monto || 0).toFixed(2)}
                  </td>
                </tr>
              `).join('')}
            </tbody>
          </table>
        </div>
      `
    }
  }

  async function renderComisiones() {
    const el = document.getElementById('fin-content')
    el.innerHTML = '<p class="text-gray-400 text-sm p-4">Cargando...</p>'

    const { data } = await supabase
      .from('cobros')
      .select(`*, clientes(nombre), cotizaciones(numero, total_final, total_neto)`)
      .order('fecha', { ascending: false })

    const cobrosConCot = (data || []).filter(c => c.cotizaciones)

    const comisionesCalc = cobrosConCot.map(c => {
      const totalFinal = c.cotizaciones.total_final || 0
      const totalNeto  = c.cotizaciones.total_neto || 0
      const totalBase  = c.cotizaciones?.total_final || 0
      const utilidad   = totalBase - totalNeto
      const pctUtil    = totalBase > 0 ? utilidad / totalBase : 0
      const montoBase  = Math.min(c.monto_usd, totalBase)
      const utilidadDelCobro = montoBase * pctUtil
      const comision   = utilidadDelCobro * 0.25
      return { ...c, utilidadDelCobro, comision }
    })

    const pendientes  = comisionesCalc.filter(c => !c.liquidado)
    const liquidadas  = comisionesCalc.filter(c => c.liquidado)
    const totalPend   = pendientes.reduce((s, c) => s + c.comision, 0)
    const totalLiquid = liquidadas.reduce((s, c) => s + c.comision, 0)
    el.innerHTML = `
      <!-- Resumen -->
      <div class="grid grid-cols-2 gap-3 mb-4">
        <div class="bg-purple-50 border border-purple-200 rounded-xl p-3 text-center">
          <p class="text-xs text-purple-600 font-medium">Pendiente de liquidar</p>
          <p class="text-xl font-black text-purple-700">U$S ${totalPend.toFixed(2)}</p>
        </div>
        <div class="bg-green-50 border border-green-200 rounded-xl p-3 text-center">
          <p class="text-xs text-green-600 font-medium">Ya liquidado</p>
          <p class="text-xl font-black text-green-700">U$S ${totalLiquid.toFixed(2)}</p>
        </div>
      </div>

      <!-- Botón liquidar -->
      <div class="bg-white border border-gray-200 rounded-xl p-4 shadow-sm mb-4">
        <div class="flex items-center justify-between mb-3">
          <h3 class="font-semibold text-gray-700 text-sm">Comisiones pendientes</h3>
          <div class="flex gap-2 items-center">
            <span id="sel-count" class="text-xs text-gray-500">0 seleccionados</span>
            <button onclick="liquidarSeleccionados()"
              class="bg-purple-700 hover:bg-purple-900 text-white text-xs font-medium px-4 py-2 rounded-lg">
              💸 Liquidar seleccionados
            </button>
          </div>
        </div>

        ${pendientes.length ? `
        <div class="overflow-x-auto">
          <table class="w-full text-xs">
            <thead><tr class="bg-gray-900 text-white">
              <th class="px-2 py-2 text-center w-8">
                <input type="checkbox" id="check-all" onchange="toggleTodos(this.checked)" />
              </th>
              <th class="px-3 py-2 text-left">Fecha</th>
              <th class="px-3 py-2 text-left">Cliente</th>
              <th class="px-3 py-2 text-left">Ppto</th>
              <th class="px-3 py-2 text-right">Cobrado U$S</th>
              <th class="px-3 py-2 text-right">Utilidad</th>
              <th class="px-3 py-2 text-right">Comisión 25%</th>
              <th class="px-3 py-2 text-right">Comisión $</th>
              <th class="px-3 py-2 text-center">Acción</th>
            </tr></thead>
            <tbody>
              ${pendientes.map((c, i) => `
                <tr class="${i % 2 === 0 ? 'bg-white' : 'bg-gray-50'}" id="row-${c.id}">
                  <td class="px-2 py-2 text-center">
                    <input type="checkbox" class="check-cobro" data-id="${c.id}"
                      data-comision="${c.comision.toFixed(2)}"
                      onchange="actualizarSeleccion()" />
                  </td>
                  <td class="px-3 py-2">${new Date(c.fecha + 'T12:00:00').toLocaleDateString('es-AR')}</td>
                  <td class="px-3 py-2 font-medium">${c.clientes?.nombre || ''}</td>
                  <td class="px-3 py-2">${c.cotizaciones?.numero ? '2026-' + String(c.cotizaciones.numero).padStart(3,'0') : '-'}</td>
                  <td class="px-3 py-2 text-right font-bold text-green-700">U$S ${(c.monto_usd||0).toFixed(2)}</td>
                  <td class="px-3 py-2 text-right text-gray-600">U$S ${c.utilidadDelCobro.toFixed(2)}</td>
                  <td class="px-3 py-2 text-right font-bold text-purple-700">U$S ${c.comision.toFixed(2)}</td>
<td class="px-3 py-2 text-right text-purple-600">$ ${Math.round(c.comision*(c.tc||1150)).toLocaleString('es-AR')}</td>
                  <td class="px-3 py-2 text-center">
                    <button onclick="liquidarVentaDesdeComisiones('${c.cotizacion_id}', ${c.cotizaciones?.total_final || 0}, ${c.cotizaciones?.total_neto || 0}, '${c.cotizaciones?.numero || 0}')"
                      class="text-xs bg-purple-100 hover:bg-purple-200 text-purple-700 px-2 py-1 rounded font-medium">
                      💸 100%
                    </button>
                  </td>
                </tr>              `).join('')}
            </tbody>
          </table>
        </div>
        ` : '<p class="text-gray-400 text-sm text-center py-4">No hay comisiones pendientes.</p>'}
      </div>

      <!-- Historial liquidaciones -->
      <div class="bg-white border border-gray-200 rounded-xl p-4 shadow-sm" id="hist-liquid">
        <h3 class="font-semibold text-gray-700 text-sm mb-3">Historial de liquidaciones</h3>
        <p class="text-gray-400 text-xs">Cargando...</p>
      </div>
    `

    // Cargar historial
    cargarHistorialLiquidaciones()

    window.toggleTodos = (checked) => {
      document.querySelectorAll('.check-cobro').forEach(c => c.checked = checked)
      actualizarSeleccion()
    }

    window.actualizarSeleccion = () => {
      const checks = [...document.querySelectorAll('.check-cobro:checked')]
      const total = checks.reduce((s, c) => s + parseFloat(c.dataset.comision), 0)
      document.getElementById('sel-count').textContent =
        `${checks.length} seleccionados — U$S ${total.toFixed(2)}`
    }

window.liquidarSeleccionados = async () => {
      const checks = [...document.querySelectorAll('.check-cobro:checked')]
      if (!checks.length) { alert('Seleccioná al menos un cobro'); return }

      const total = checks.reduce((s, c) => s + parseFloat(c.dataset.comision), 0)
      const tc = parseFloat(prompt('Tipo de cambio $ / U$S:', '1150')) || 1150

      if (!confirm(`¿Confirmás liquidar U$S ${total.toFixed(2)} ($ ${Math.round(total * tc).toLocaleString('es-AR')})?`)) return

      const { data: liq, error } = await supabase
        .from('liquidaciones')
        .insert({
          fecha: new Date().toISOString().split('T')[0],
          monto_usd: total,
          monto_ars: total * tc,
          tc,
          notas: `Liquidación de ${checks.length} cobro(s)`
        })
        .select().single()

      if (error) { alert('Error: ' + error.message); return }

      const cobrosIds = checks.map(c => c.dataset.id)
      await supabase.from('liquidacion_cobros').insert(
        checks.map(c => ({
          liquidacion_id: liq.id,
          cobro_id: c.dataset.id,
          comision_usd: parseFloat(c.dataset.comision)
        }))
      )
      await supabase.from('cobros')
        .update({ liquidado: true, liquidacion_id: liq.id })
        .in('id', cobrosIds)

      alert(`✅ Liquidación registrada por U$S ${total.toFixed(2)}`)
      renderComisiones()
    }

    window.liquidarVentaDesdeComisiones = async (cotId, totalFinal, totalNeto, numero) => {
      // Verificar si ya hay liquidación para esta cotización
      const { data: cobrosYaLiquid } = await supabase
        .from('cobros')
        .select('id, liquidado')
        .eq('cotizacion_id', cotId)
        .eq('liquidado', true)

      if (cobrosYaLiquid?.length) {
        if (!confirm(`Esta venta ya tiene ${cobrosYaLiquid.length} cobro(s) liquidado(s). ¿Querés liquidar de todas formas el 100%?`)) return
      }

      const utilidad = totalFinal - totalNeto
      const comision = utilidad * 0.25
      const tc = parseFloat(prompt('Tipo de cambio $ / U$S:', '1150')) || 1150

      if (!confirm(`¿Liquidar comisión completa de la venta 2026-${String(numero).padStart(3,'0')}?\nMonto: U$S ${comision.toFixed(2)} ($ ${Math.round(comision * tc).toLocaleString('es-AR')})`)) return

      const { data: liq, error } = await supabase
        .from('liquidaciones')
        .insert({
          fecha: new Date().toISOString().split('T')[0],
          monto_usd: comision,
          monto_ars: comision * tc,
          tc,
          notas: `Liquidación 100% venta 2026-${String(numero).padStart(3,'0')}`
        })
        .select().single()

      if (error) { alert('Error: ' + error.message); return }

      const { data: cobrosVenta } = await supabase
        .from('cobros')
        .select('id')
        .eq('cotizacion_id', cotId)

      if (cobrosVenta?.length) {
        const ids = cobrosVenta.map(c => c.id)
        await supabase.from('liquidacion_cobros').insert(
          ids.map(id => ({
            liquidacion_id: liq.id,
            cobro_id: id,
            comision_usd: comision / ids.length
          }))
        )
        await supabase.from('cobros')
          .update({ liquidado: true, liquidacion_id: liq.id })
          .in('id', ids)
      }

      alert(`✅ Comisión de U$S ${comision.toFixed(2)} liquidada`)
      renderComisiones()
    }  
  }

async function cargarHistorialLiquidaciones() {
    const { data } = await supabase
      .from('liquidaciones')
      .select(`
        *,
        liquidacion_cobros(
          id,
          comision_usd,
          cobros(
            monto_usd,
            clientes(nombre),
            cotizaciones(numero)
          )
        )
      `)
      .order('fecha', { ascending: false })
      .limit(20)

    const el = document.getElementById('hist-liquid')
    if (!el) return

    if (!data?.length) {
      el.innerHTML = `
        <h3 class="font-semibold text-gray-700 text-sm mb-3">Historial de liquidaciones</h3>
        <p class="text-gray-400 text-xs text-center py-4">No hay liquidaciones registradas.</p>
      `
      return
    }

    el.innerHTML = `
      <h3 class="font-semibold text-gray-700 text-sm mb-3">Historial de liquidaciones</h3>
      <div class="space-y-3">
        ${data.map((l, i) => {
          const cobros = l.liquidacion_cobros || []
          // Obtener pptos y clientes únicos
          const pptos = [...new Set(cobros
            .map(lc => lc.cobros?.cotizaciones?.numero)
            .filter(Boolean)
            .map(n => `2026-${String(n).padStart(3,'0')}`)
          )].join(', ') || l.notas || '-'

          const clientes = [...new Set(cobros
            .map(lc => lc.cobros?.clientes?.nombre)
            .filter(Boolean)
          )].join(', ') || '-'

          return `
            <div class="border border-gray-200 rounded-lg overflow-hidden">
              <div class="bg-gray-50 px-4 py-2 flex items-center justify-between">
                <div class="flex items-center gap-4">
                  <div>
                    <p class="text-xs text-gray-400">Fecha</p>
                    <p class="text-sm font-bold text-gray-800">${new Date(l.fecha + 'T12:00:00').toLocaleDateString('es-AR')}</p>
                  </div>
                  <div>
                    <p class="text-xs text-gray-400">Cliente(s)</p>
                    <p class="text-sm font-medium text-gray-800">${clientes}</p>
                  </div>
                  <div>
                    <p class="text-xs text-gray-400">Presupuesto(s)</p>
                    <p class="text-sm font-medium text-gray-800">${pptos}</p>
                  </div>
                </div>
                <div class="flex items-center gap-4">
                  <div class="text-right">
                    <p class="text-xs text-gray-400">Monto liquidado</p>
                    <p class="text-sm font-black text-purple-700">U$S ${(l.monto_usd||0).toFixed(2)}</p>
                    <p class="text-xs text-purple-500">$ ${Math.round(l.monto_ars||0).toLocaleString('es-AR')} (T/C ${l.tc})</p>
                  </div>
                  <button onclick="borrarLiquidacion('${l.id}')"
class="text-red-400 hover:text-red-600 font-bold text-lg">✕</button>
                <button onclick="imprimirReciboComision('${l.id}')"
                  class="text-blue-500 hover:text-blue-700 font-bold text-lg ml-2">🖨️</button>                </div>
              </div>
              ${cobros.length ? `
              <table class="w-full text-xs">
                <thead><tr class="bg-gray-100 text-gray-500">
                  <th class="px-3 py-1 text-left">Cliente</th>
                  <th class="px-3 py-1 text-left">Ppto</th>
                  <th class="px-3 py-1 text-right">Cobrado</th>
                  <th class="px-3 py-1 text-right">Comisión</th>
                </tr></thead>
                <tbody>
                  ${cobros.map(lc => `
                    <tr class="border-t border-gray-100">
                      <td class="px-3 py-1">${lc.cobros?.clientes?.nombre || '-'}</td>
                      <td class="px-3 py-1">${lc.cobros?.cotizaciones?.numero ? '2026-' + String(lc.cobros.cotizaciones.numero).padStart(3,'0') : '-'}</td>
                      <td class="px-3 py-1 text-right text-green-700">U$S ${(lc.cobros?.monto_usd||0).toFixed(2)}</td>
                      <td class="px-3 py-1 text-right text-purple-700">U$S ${(lc.comision_usd||0).toFixed(2)}</td>
                    </tr>
                  `).join('')}
                </tbody>
              </table>
              ` : `<p class="text-xs text-gray-400 px-4 py-2">${l.notas || ''}</p>`}
            </div>
          `
        }).join('')}
      </div>
    `
window.imprimirReciboComision = async (id) => {
      const liq = data.find(l => l.id === id)
      if (!liq) return

      const cobros = liq.liquidacion_cobros || []
      const clientes = [...new Set(cobros.map(lc => lc.cobros?.clientes?.nombre).filter(Boolean))].join(', ')
      const pptos = [...new Set(cobros.map(lc => lc.cobros?.cotizaciones?.numero).filter(Boolean))].join(', ')

      await generarReciboComision({
        ...liq,
        vendedor_nombre: 'Vendedor DACAR',
        notas: `Ventas: ${pptos} | Clientes: ${clientes}`
      })
    }
    
    window.borrarLiquidacion = async (id) => {
      const clave = prompt('Clave de gerencia:')
      if (clave !== 'dacar2024') { alert('Clave incorrecta'); return }
      if (!confirm('¿Confirmás? Esto va a desmarcar los cobros como liquidados.')) return

      const { data: lc } = await supabase
        .from('liquidacion_cobros')
        .select('cobro_id')
        .eq('liquidacion_id', id)

      const ids = (lc || []).map(x => x.cobro_id)
      if (ids.length) {
        await supabase.from('cobros')
          .update({ liquidado: false, liquidacion_id: null })
          .in('id', ids)
      }

      await supabase.from('liquidaciones').delete().eq('id', id)
      renderComisiones()
    }
  }  renderPendientes()

  window.abrirSimuladorFlujo = () => {
    let ventaTotal = 0;
    let costoTotal = 0;
    let pptoSeleccionado = null;
    let saldoInicial = 0;
    let cobros = [
      { id: 1, dias: 0, pct: 33 },
      { id: 2, dias: 30, pct: 33 },
      { id: 3, dias: 60, pct: 34 }
    ];
    let pagos = [
      { id: 1, dias: 15, pct: 100 }
    ];

    const modal = document.createElement('div');
    modal.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,0.6);z-index:9999;display:flex;align-items:center;justify-content:center;overflow-y:auto;padding:20px;';
    
    modal.innerHTML = `
      <div class="bg-white rounded-2xl w-full max-w-5xl max-h-[95vh] flex flex-col overflow-hidden shadow-2xl">
        <div class="bg-gray-900 p-4 flex justify-between items-center text-white">
          <h2 class="text-lg font-bold">📊 Simulador Dinámico de Flujo de Caja</h2>
          <button id="btn-cerrar-sim" class="text-gray-400 hover:text-white text-2xl font-bold">×</button>
        </div>

        <div class="p-6 overflow-y-auto flex-1 bg-gray-50 flex gap-6">
          
          <div class="w-1/3 flex flex-col gap-4">
            <div class="bg-white p-4 rounded-xl border border-gray-200 shadow-sm">
            <div class="mb-3">
                <label class="block text-xs font-bold text-gray-500 mb-1">Cargar desde presupuesto</label>
                <input type="text" id="sim-busca-ppto" placeholder="🔍 Buscar cliente u N° ppto..."
                  class="w-full border-gray-300 rounded-lg text-xs" />
                <div id="sim-drop-ppto" class="hidden mt-1 bg-white border border-gray-200 rounded-lg shadow-lg max-h-40 overflow-y-auto z-50"></div>
              </div>
              <label class="block text-xs font-bold text-gray-500 mb-1">💵 Fondos en caja (U$S)</label>
              <input type="number" id="sim-saldo" value="0" class="w-full border-gray-300 rounded-lg font-bold text-blue-700 mb-3" placeholder="0.00" />
              <label class="block text-xs font-bold text-gray-500 mb-1">Venta Total (U$S)</label>
              <input type="number" id="sim-venta" value="${ventaTotal}" class="w-full border-gray-300 rounded-lg font-bold text-green-700" />
              <label class="block text-xs font-bold text-gray-500 mt-2 mb-1">Costo Materiales (U$S)</label>
              <input type="number" id="sim-costo" value="${costoTotal}" class="w-full border-gray-300 rounded-lg font-bold text-red-700" />
            </div>

            <div class="bg-white p-4 rounded-xl border border-gray-200 shadow-sm">
              <div class="flex justify-between items-end mb-2">
                <h3 class="text-sm font-bold text-gray-700">🟢 Cobros</h3>
                <button id="btn-add-cobro" class="text-[10px] bg-green-100 text-green-700 px-2 py-1 rounded font-bold hover:bg-green-200">+ Agregar</button>
              </div>
              <div id="lista-cobros" class="space-y-2 mb-1"></div>
              <p id="err-cobros" class="text-[10px] text-red-500 font-bold hidden">La suma debe ser 100%</p>
            </div>

            <div class="bg-white p-4 rounded-xl border border-gray-200 shadow-sm">
              <div class="flex justify-between items-end mb-2">
                <h3 class="text-sm font-bold text-gray-700">🔴 Pagos (Prov.)</h3>
                <button id="btn-add-pago" class="text-[10px] bg-red-100 text-red-700 px-2 py-1 rounded font-bold hover:bg-red-200">+ Agregar</button>
              </div>
              <div id="lista-pagos" class="space-y-2 mb-1"></div>
              <p id="err-pagos" class="text-[10px] text-red-500 font-bold hidden">La suma debe ser 100%</p>
            </div>
          </div>

          <div class="w-2/3 flex flex-col gap-4">
            <div id="panel-resultados" class="grid grid-cols-3 gap-4"></div>
            
            <div class="bg-white p-4 rounded-xl border border-gray-200 shadow-sm flex-1 relative min-h-[300px]">
              <canvas id="grafico-caja"></canvas>
            </div>
          </div>

        </div>
      </div>
    `;
    document.body.appendChild(modal);

    const inputBusca = modal.querySelector('#sim-busca-ppto')
    const dropPpto = modal.querySelector('#sim-drop-ppto')

    supabase
      .from('cotizaciones')
      .select('id, numero, total_final, total_neto, clientes(nombre)')
      .order('numero', { ascending: false })
      .limit(100)
      .then(({ data: pptos }) => {
        inputBusca.addEventListener('input', e => {
          const txt = e.target.value.toLowerCase()
          if (!txt) { dropPpto.classList.add('hidden'); return }
          const filtrados = (pptos || []).filter(p =>
            p.clientes?.nombre?.toLowerCase().includes(txt) ||
            String(p.numero).includes(txt)
          ).slice(0, 8)
          if (!filtrados.length) { dropPpto.classList.add('hidden'); return }
          const nomEsc = (n) => String(n||'').replace(/'/g,"\\'")
          dropPpto.innerHTML = filtrados.map(p => `
            <div class="px-3 py-2 text-xs cursor-pointer hover:bg-green-50 border-b border-gray-100"
              onclick="window.cargarPptoSim('${p.id}', ${p.total_final}, ${p.total_neto}, '${nomEsc(p.clientes?.nombre)}', ${p.numero})">
              <span class="font-bold">2026-${String(p.numero).padStart(3,'0')}</span>
              <span class="text-gray-500 ml-2">${p.clientes?.nombre || ''}</span>
              <span class="text-green-700 ml-2 font-medium">U$S ${(p.total_final||0).toFixed(0)}</span>
            </div>
          `).join('')
          dropPpto.classList.remove('hidden')
        })

        window.cargarPptoSim = (id, totalFinal, totalNeto, nombre, numero) => {
          pptoSeleccionado = { id, nombre, numero }
          ventaTotal = totalFinal
          costoTotal = totalNeto
          document.getElementById('sim-venta').value = totalFinal.toFixed(2)
          document.getElementById('sim-costo').value = totalNeto.toFixed(2)
          inputBusca.value = `2026-${String(numero).padStart(3,'0')} — ${nombre}`
          dropPpto.classList.add('hidden')
          calcularFlujo()
        }
      })

    let chartInstance = null;
    const renderListas = () => {
      document.getElementById('lista-cobros').innerHTML = cobros.map(c => `
        <div class="flex gap-1 items-center">
          <input type="number" data-tipo="cobro" data-id="${c.id}" data-campo="dias" value="${c.dias}" class="sim-input w-1/2 p-1 text-xs border rounded" placeholder="Días">
          <input type="number" data-tipo="cobro" data-id="${c.id}" data-campo="pct" value="${c.pct}" class="sim-input w-1/2 p-1 text-xs border rounded" placeholder="%">
          <button onclick="window.eliminarHito('cobro', ${c.id})" class="text-red-400 hover:text-red-600 font-bold px-1">✕</button>
        </div>
      `).join('');

      document.getElementById('lista-pagos').innerHTML = pagos.map(p => `
        <div class="flex gap-1 items-center">
          <input type="number" data-tipo="pago" data-id="${p.id}" data-campo="dias" value="${p.dias}" class="sim-input w-1/2 p-1 text-xs border rounded" placeholder="Días">
          <input type="number" data-tipo="pago" data-id="${p.id}" data-campo="pct" value="${p.pct}" class="sim-input w-1/2 p-1 text-xs border rounded" placeholder="%">
          <button onclick="window.eliminarHito('pago', ${p.id})" class="text-red-400 hover:text-red-600 font-bold px-1">✕</button>
        </div>
      `).join('');

      calcularFlujo();
    };

    const calcularFlujo = () => {
      ventaTotal = parseFloat(document.getElementById('sim-venta').value) || 0;
      costoTotal = parseFloat(document.getElementById('sim-costo').value) || 0;
      saldoInicial = parseFloat(document.getElementById('sim-saldo').value) || 0;

      const sumaCobros = cobros.reduce((s, c) => s + c.pct, 0);
      const sumaPagos = pagos.reduce((s, p) => s + p.pct, 0);
      
      document.getElementById('err-cobros').classList.toggle('hidden', sumaCobros === 100);
      document.getElementById('err-pagos').classList.toggle('hidden', sumaPagos === 100);

      if (sumaCobros !== 100 || sumaPagos !== 100) return;

      let eventos = [];
      cobros.forEach(c => eventos.push({ dia: c.dias, monto: ventaTotal * (c.pct / 100) }));
      pagos.forEach(p => eventos.push({ dia: p.dias, monto: -(costoTotal * (p.pct / 100)) }));

      let cajaPorDia = {};
      eventos.forEach(ev => {
        cajaPorDia[ev.dia] = (cajaPorDia[ev.dia] || 0) + ev.monto;
      });

      const diasUnicos = Object.keys(cajaPorDia).map(Number).sort((a, b) => a - b);
      const maxDia = diasUnicos.length > 0 ? diasUnicos[diasUnicos.length - 1] : 0;
      
      let labels = [];
      let dataCaja = [];
      let cajaAcumulada = saldoInicial;
      let peorCaja = saldoInicial; // Se ajusta para que no asuma 0 si arranca en positivo
      let diaPeorCaja = 0;

      for (let i = 0; i <= maxDia + 5; i++) {
        if (cajaPorDia[i]) {
          cajaAcumulada += cajaPorDia[i];
        }
        labels.push(`Día ${i}`);
        dataCaja.push(cajaAcumulada);
        
        if (cajaAcumulada < peorCaja) {
          peorCaja = cajaAcumulada;
          diaPeorCaja = i;
        }
      }

      const utilidad = ventaTotal - costoTotal;

      document.getElementById('panel-resultados').innerHTML = `
        <div class="bg-gray-100 p-2 rounded-xl text-center border ${peorCaja < 0 ? 'border-red-400 bg-red-50' : 'border-green-400 bg-green-50'}">
          <p class="text-[10px] text-gray-500 font-bold uppercase">Valle Crítico</p>
          <p class="text-xl font-black ${peorCaja < 0 ? 'text-red-600' : 'text-green-600'}">
            ${peorCaja < 0 ? '- U$S ' + Math.abs(peorCaja).toFixed(2) : 'U$S 0.00'}
          </p>
        </div>
        <div class="bg-blue-50 p-2 rounded-xl text-center border border-blue-100">
          <p class="text-[10px] text-blue-600 font-bold uppercase">Utilidad</p>
          <p class="text-xl font-black text-blue-800">U$S ${utilidad.toFixed(2)}</p>
        </div>
        <div class="bg-purple-50 p-2 rounded-xl text-center border border-purple-100">
          <p class="text-[10px] text-purple-600 font-bold uppercase">Comisión (25%)</p>
          <p class="text-xl font-black text-purple-800">U$S ${(utilidad * 0.25).toFixed(2)}</p>
        </div>
      `;

      const ctx = document.getElementById('grafico-caja');
      if (!ctx) return;

      if (chartInstance) {
        chartInstance.data.labels = labels;
        chartInstance.data.datasets[0].data = dataCaja;
        chartInstance.update();
      } else {
        chartInstance = new Chart(ctx, {
          type: 'line',
          data: {
            labels: labels,
            datasets: [{
              label: 'Saldo de Caja (U$S)',
              data: dataCaja,
              borderColor: '#059669',
              backgroundColor: 'rgba(5, 150, 105, 0.2)',
              fill: true,
              stepped: 'after',
              tension: 0
            }]
          },
          options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
              legend: { display: false }
            },
            scales: {
              y: { grid: { color: '#e5e7eb' } },
              x: { grid: { display: false } }
            }
          }
        });
      }
    };

    modal.addEventListener('input', (e) => {
      if (e.target.classList.contains('sim-input')) {
        const id = parseInt(e.target.dataset.id);
        const tipo = e.target.dataset.tipo;
        const campo = e.target.dataset.campo;
        const valor = parseFloat(e.target.value) || 0;
        
        if (tipo === 'cobro') cobros.find(c => c.id === id)[campo] = valor;
        if (tipo === 'pago') pagos.find(p => p.id === id)[campo] = valor;
        calcularFlujo();
      }
      if (e.target.id === 'sim-venta' || e.target.id === 'sim-costo' || e.target.id === 'sim-saldo') calcularFlujo();
    });

    window.eliminarHito = (tipo, id) => {
      if (tipo === 'cobro' && cobros.length > 1) cobros = cobros.filter(c => c.id !== id);
      if (tipo === 'pago' && pagos.length > 1) pagos = pagos.filter(p => p.id !== id);
      renderListas();
    };

    document.getElementById('btn-add-cobro').addEventListener('click', () => {
      cobros.push({ id: Date.now(), dias: 0, pct: 0 });
      renderListas();
    });

    document.getElementById('btn-add-pago').addEventListener('click', () => {
      pagos.push({ id: Date.now(), dias: 0, pct: 0 });
      renderListas();
    });

    document.getElementById('btn-cerrar-sim').addEventListener('click', () => {
      if (chartInstance) chartInstance.destroy();
      modal.remove();
      delete window.eliminarHito;
    });

    setTimeout(() => renderListas(), 100);
    function esc(s) { return String(s || '').replace(/'/g, "\\'") }
  };
}